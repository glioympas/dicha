


<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col">
			<div class="card">
				<div class="card-header">
					<?php echo e(isset($company) ? __("Edit Company") . " #" . $company->id : __("Create a new company")); ?>

				</div>
				<div class="card-body">
					<form enctype='multipart/form-data' class="ajax-form <?php echo e(isset($company) ? 'updateCompanyForm' : 'createCompanyForm'); ?>" method="<?php echo e(isset($company) ? 'PUT' : 'POST'); ?>" action="<?php echo e(isset($company) ? route('companies.update', $company->id) : route('companies.store')); ?>">

						<!-- Δεν βάζω csrf token γιατί το έχω κάνει set sto jQuery AJAX setup και η συγκεκριμένη φόρμα θα φεύγει με AJAX
							Αυτο διευκολύνει στο όταν στέλνω AJAX requests χωρίς φόρμες να μην χρειάζεται να το βάζω manually στο body του request κάθε φορά.
						 -->

		 				<div class="form-group">
		 					<label for="name"><?php echo e(__("Name")); ?>:</label>
		 					<input name="name" id="name" required value="<?php echo e(isset($company) ? $company->name : ''); ?>" type="text" class="form-control">
		 				</div>

		 				<div class="form-group">
		 					<label for="name"><?php echo e(__("Email")); ?>:</label>
		 					<input name="email" id="email" required value="<?php echo e(isset($company) ? $company->email : ''); ?>" type="text" class="form-control">
		 				</div>

		 				<div class="form-group">
		 					<label for="name"><?php echo e(__("Activity")); ?>:</label>
		 					<input name="activity" id="activity" value="<?php echo e(isset($company) ? $company->activity : ''); ?>" type="text" class="form-control">
		 				</div>

		 				<div class="form-group">
		 					<label for="name"><?php echo e(__("Website")); ?>:</label>
		 					<input name="website" id="website" value="<?php echo e(isset($company) ? $company->website : ''); ?>" type="text" class="form-control">
		 				</div>

		 				<div class="mt-4">
		 					<button type="submit" class="btn btn-primary btn-sm"><?php echo e(isset($company) ? __("Update") : __("Create")); ?></button>
		 				</div>

					</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dicha\resources\views/companies/company_form.blade.php ENDPATH**/ ?>