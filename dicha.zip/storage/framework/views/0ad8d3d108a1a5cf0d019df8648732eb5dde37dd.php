<tr data-employee-id="<?php echo e($employee->id); ?>">
	<td><?php echo e($employee->name); ?></td>
	<td>
		<a href="<?php echo e(route('companies.edit', $employee->company->id)); ?>" class="text-primary"><?php echo e($employee->company->name); ?></a>
	</td>
	<td><?php echo e($employee->email); ?></td>
	<td><?php echo e($employee->phone); ?></td>
	<td>
		<div class="d-flex">
			<a href="<?php echo e(route('employees.edit', $employee->id)); ?>" class="btn btn-sm btn-info"><?php echo e(__("Edit")); ?></a>

			<form method="DELETE" action="<?php echo e(route('employees.destroy' , $employee->id)); ?>" class="d-inline-block ml-1">
				<button class="btn btn-sm btn-danger"><?php echo e(__("Delete")); ?></button>
			</form>
		</div>
	</td>
</tr><?php /**PATH C:\xampp\htdocs\dicha\resources\views/employees/employee_row.blade.php ENDPATH**/ ?>