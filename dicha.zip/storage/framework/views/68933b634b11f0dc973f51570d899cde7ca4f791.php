<tr data-company-id="<?php echo e($company->id); ?>">
	<td><?php echo e($company->name); ?></td>
	<td><?php echo e($company->employees->count()); ?></td>
	<td><?php echo e($company->email); ?></td>
	<td>
		<?php if($company->website): ?>
			<a target="_blank" class="text-primary" href="<?php echo e($company->website); ?>"><?php echo e($company->website); ?></a>
		<?php else: ?>
			-
		<?php endif; ?>
	</td>
	<td>
		<div class="d-flex">
			<a href="<?php echo e(route('companies.edit' , $company->id)); ?>" class="btn btn-sm btn-info"><?php echo e(__("Edit")); ?></a>

			<a href="<?php echo e(route('employees.index', ['company_id' => $company->id])); ?>" class="btn btn-sm btn-success ml-1"><?php echo e(__("Employees")); ?></a>

			<form action="<?php echo e(route('companies.destroy' , $company->id)); ?>" class="d-inline-block ml-1 ajax-form deleteCompanyForm" method="DELETE">
				<button type="submit" class="btn btn-sm btn-danger"><?php echo e(__("Delete")); ?></button>
			</form>
		</div>
	</td>
</tr><?php /**PATH C:\xampp\htdocs\dicha\resources\views/companies/company_row.blade.php ENDPATH**/ ?>