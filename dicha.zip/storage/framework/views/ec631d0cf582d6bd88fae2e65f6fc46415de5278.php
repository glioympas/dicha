


<?php $__env->startSection('content'); ?>


<div class="row">
	<div class="col">
		<div class="card">
			<div class="card-header"><?php echo e(isset($employee) ? __("Edit employee") . " #" . $employee->id : __("Create a new employee")); ?></div>
			<div class="card-body">
				<form class="ajax-form <?php echo e(isset($employee) ? 'updateEmployeeForm' : 'createEmployeeForm'); ?>" method="<?php echo e(isset($employee) ? 'PUT' : 'POST'); ?>" action="<?php echo e(isset($employee) ? route('employees.update', $employee->id) : route('employees.store')); ?>">
					
					<div class="form-group">
						<label for="name"><?php echo e(__("Name")); ?>:</label>
						<input required value="<?php echo e(isset($employee) ? $employee->name : ''); ?>" name="name" id="name" type="text" class="form-control">
					</div>

					<div class="form-group">
						<label for="company_id"><?php echo e(__("Company")); ?>:</label>
						<select required class="select2 form-control" name="company_id" id="company_id">
							<?php $__currentLoopData = $allCompanies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option <?php echo e(isset($employee) && $employee->company_id == $company->id ? 'selected' : ''); ?> value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>

					<div class="form-group">
						<label for="email"><?php echo e(__("Email")); ?>:</label>
						<input required value="<?php echo e(isset($employee) ? $employee->email : ''); ?>" name="email" id="email" type="text" class="form-control">
					</div>

					<div class="form-group">
						<label for="phone"><?php echo e(__("Phone")); ?>:</label>
						<input value="<?php echo e(isset($employee) ? $employee->phone : ''); ?>" name="phone" id="phone" type="text" class="form-control">
					</div>

					<div class="mt-4">
						<button class="btn btn-sm btn-primary" type="submit"><?php echo e(isset($employee) ? __("Update") : __("Create")); ?></button>
					</div>

				</form>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dicha\resources\views/employees/employee_form.blade.php ENDPATH**/ ?>