


<?php $__env->startSection('content'); ?>


<div class="row">
	<div class="col-md-12 col-lg-12">
	    <div class="card">
	        <div class="card-header"><?php echo e(__("Companies")); ?> - <?php echo e($allCount); ?> <?php echo e(__("Results")); ?></div>
	        <div class="card-body">

	        	<div class="d-flex justify-content-end">
	        		<a href="<?php echo e(route('companies.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__("Create Company")); ?></a>
	        	</div>

	            <div class="mt-4 table-responsive">
	                <table class="table table-striped">
	                    <thead>
	                        <tr>
	                            <th width="20%"><?php echo e(__("Company Name")); ?></th>
	                            <th><?php echo e(__("Employees")); ?></th>
	                            <th><?php echo e(__("Email")); ?></th>
	                            <th><?php echo e(__("Website")); ?></th>
	                            <th width="30%"><?php echo e(__("Actions")); ?></th>
	                        </tr>
	                    </thead>
	                    <tbody>
	                    	<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        <?php echo $__env->make('companies.company_row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                    </tbody>
	                </table>
	            </div>

	            <div class="mt-4 d-flex justify-content-center">
	            	<?php echo e($companies->links()); ?>

	            </div>
	        </div>
	    </div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dicha\resources\views/companies/index.blade.php ENDPATH**/ ?>