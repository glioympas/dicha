<!doctype html>
<!-- 
* Bootstrap Simple Admin Template
* Version: 2.0
* Author: Alexis Luna
* Copyright 2020 Alexis Luna
* Website: https://github.com/alexis-luna/bootstrap-simple-admin-template
-->
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dicha</title>
    <link href="/assets/vendor/fontawesome/css/fontawesome.min.css" rel="stylesheet">
    <link href="/assets/vendor/fontawesome/css/solid.min.css" rel="stylesheet">
    <link href="/assets/vendor/fontawesome/css/brands.min.css" rel="stylesheet">
    <link href="/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/css/master.css" rel="stylesheet">
    <link href="/assets/vendor/chartsjs/Chart.min.css" rel="stylesheet">
    <link href="/assets/vendor/flagiconcss/css/flag-icon.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>

<body>
    <div class="wrapper">
        <nav id="sidebar">
            <div class="py-3 sidebar-header text-center bg-dark">
               <a href="/">
                   <img height="20" src="https://www.dicha.gr/uploads/images/dicha-logo-green.png" alt="<?php echo e(config('app.name')); ?>">
               </a>
            </div>
            <ul class="pt-4 list-unstyled components text-secondary">
                <li>
                    <a href="<?php echo e(route('companies.index')); ?>"><i class="fas fa-building"></i><?php echo e(__("Companies")); ?></a>
                </li>
                <li>
                    <a href="<?php echo e(route('employees.index')); ?>"><i class="fas fa-users"></i> <?php echo e(__("Employees")); ?></a>
                </li>
            </ul>
        </nav>
        <div id="body" class="active">
            <nav class="navbar navbar-expand-lg navbar-white bg-white">
                <button type="button" id="sidebarCollapse" class="btn btn-light"><i class="fas fa-bars"></i><span></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="nav navbar-nav ml-auto">
                        <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item dropdown">
                            <div class="nav-dropdown">
                                <a href="" class="nav-item nav-link dropdown-toggle text-secondary" data-toggle="dropdown"><i class="fas fa-user"></i> <span class="ml-2"><?php echo e(auth()->user()->name); ?></span> <i class="fas fa-caret-down"></i></a>
                                <div class="dropdown-menu dropdown-menu-right nav-link-menu">
                                    <ul class="nav-list">
                                        <li><a href="" class="dropdown-item"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </nav>
            <div class="content">
                <div class="container py-4">
                    <div class="alert alert-success <?php echo e(session()->has('success') ? '' : 'd-none'); ?> top-success"><?php echo e(session('success')); ?></div>
                    <div class="alert alert-danger <?php echo e(session()->has('error') ? '' : 'd-none'); ?> top-error"><?php echo e(session('error')); ?></div>
                    <div class="mt-4">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>s
    <script src="assets/js/script.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\dicha\resources\views/layouts/app.blade.php ENDPATH**/ ?>