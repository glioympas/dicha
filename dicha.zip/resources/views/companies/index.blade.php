@extends('layouts.app')


@section('content')


<div class="row">
	<div class="col-md-12 col-lg-12">
	    <div class="card">
	        <div class="card-header">{{ __("Companies") }} - {{ $allCount }} {{  __("Results") }}</div>
	        <div class="card-body">

	        	<div class="d-flex justify-content-end">
	        		<a href="{{ route('companies.create') }}" class="btn btn-sm btn-primary">{{ __("Create Company") }}</a>
	        	</div>

	            <div class="mt-4 table-responsive">
	                <table class="table table-striped">
	                    <thead>
	                        <tr>
	                            <th width="20%">{{ __("Company Name") }}</th>
	                            <th>{{ __("Employees") }}</th>
	                            <th>{{ __("Email") }}</th>
	                            <th>{{ __("Website") }}</th>
	                            <th width="30%">{{ __("Actions") }}</th>
	                        </tr>
	                    </thead>
	                    <tbody>
	                    	@foreach($companies as $company)
		                        @include('companies.company_row')
	                        @endforeach
	                    </tbody>
	                </table>
	            </div>

	            <div class="mt-4 d-flex justify-content-center">
	            	{{ $companies->links() }}
	            </div>
	        </div>
	    </div>
	</div>
</div>


@endsection