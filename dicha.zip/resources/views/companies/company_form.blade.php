@extends('layouts.app')


@section('content')
	<div class="row">
		<div class="col">
			<div class="card">
				<div class="card-header">
					{{ isset($company) ? __("Edit Company") . " #" . $company->id : __("Create a new company")  }}
				</div>
				<div class="card-body">
					<form enctype='multipart/form-data' class="ajax-form {{ isset($company) ? 'updateCompanyForm' : 'createCompanyForm' }}" method="{{ isset($company) ? 'PUT' : 'POST' }}" action="{{ isset($company) ? route('companies.update', $company->id) : route('companies.store') }}">

						<!-- Δεν βάζω csrf token γιατί το έχω κάνει set sto jQuery AJAX setup και η συγκεκριμένη φόρμα θα φεύγει με AJAX
							Αυτο διευκολύνει στο όταν στέλνω AJAX requests χωρίς φόρμες να μην χρειάζεται να το βάζω manually στο body του request κάθε φορά.
						 -->

		 				<div class="form-group">
		 					<label for="name">{{ __("Name") }}:</label>
		 					<input name="name" id="name" required value="{{ isset($company) ? $company->name : '' }}" type="text" class="form-control">
		 				</div>

		 				<div class="form-group">
		 					<label for="name">{{ __("Email") }}:</label>
		 					<input name="email" id="email" required value="{{ isset($company) ? $company->email : '' }}" type="text" class="form-control">
		 				</div>

		 				<div class="form-group">
		 					<label for="name">{{ __("Activity") }}:</label>
		 					<input name="activity" id="activity" value="{{ isset($company) ? $company->activity : '' }}" type="text" class="form-control">
		 				</div>

		 				<div class="form-group">
		 					<label for="name">{{ __("Website") }}:</label>
		 					<input name="website" id="website" value="{{ isset($company) ? $company->website : '' }}" type="text" class="form-control">
		 				</div>

		 				<div class="mt-4">
		 					<button type="submit" class="btn btn-primary btn-sm">{{ isset($company) ? __("Update") : __("Create") }}</button>
		 				</div>

					</form>
				</div>
			</div>
		</div>
	</div>
@endsection