<tr data-company-id="{{ $company->id }}">
	<td>{{ $company->name }}</td>
	<td>{{ $company->employees->count() }}</td>
	<td>{{ $company->email }}</td>
	<td>
		@if($company->website)
			<a target="_blank" class="text-primary" href="{{ $company->website }}">{{ $company->website }}</a>
		@else
			-
		@endif
	</td>
	<td>
		<div class="d-flex">
			<a href="{{ route('companies.edit' , $company->id) }}" class="btn btn-sm btn-info">{{ __("Edit") }}</a>

			<a href="{{ route('employees.index', ['company_id' => $company->id]) }}" class="btn btn-sm btn-success ml-1">{{ __("Employees") }}</a>

			<form action="{{ route('companies.destroy' , $company->id) }}" class="d-inline-block ml-1 ajax-form deleteCompanyForm" method="DELETE">
				<button type="submit" class="btn btn-sm btn-danger">{{ __("Delete") }}</button>
			</form>
		</div>
	</td>
</tr>