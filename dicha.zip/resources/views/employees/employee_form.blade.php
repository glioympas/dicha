@extends('layouts.app')


@section('content')


<div class="row">
	<div class="col">
		<div class="card">
			<div class="card-header">{{ isset($employee) ? __("Edit employee") . " #" . $employee->id : __("Create a new employee")  }}</div>
			<div class="card-body">
				<form class="ajax-form {{ isset($employee) ? 'updateEmployeeForm' : 'createEmployeeForm' }}" method="{{ isset($employee) ? 'PUT' : 'POST' }}" action="{{ isset($employee) ? route('employees.update', $employee->id) : route('employees.store') }}">
					
					<div class="form-group">
						<label for="name">{{ __("Name") }}:</label>
						<input required value="{{ isset($employee) ? $employee->name : '' }}" name="name" id="name" type="text" class="form-control">
					</div>

					<div class="form-group">
						<label for="company_id">{{ __("Company") }}:</label>
						<select required class="select2 form-control" name="company_id" id="company_id">
							@foreach($allCompanies as $company)
                               <option {{ isset($employee) && $employee->company_id == $company->id ? 'selected' : '' }} value="{{ $company->id }}">{{ $company->name }}</option>
							@endforeach
						</select>
					</div>

					<div class="form-group">
						<label for="email">{{ __("Email") }}:</label>
						<input required value="{{ isset($employee) ? $employee->email : '' }}" name="email" id="email" type="text" class="form-control">
					</div>

					<div class="form-group">
						<label for="phone">{{ __("Phone") }}:</label>
						<input value="{{ isset($employee) ? $employee->phone : '' }}" name="phone" id="phone" type="text" class="form-control">
					</div>

					<div class="mt-4">
						<button class="btn btn-sm btn-primary" type="submit">{{ isset($employee) ? __("Update") : __("Create") }}</button>
					</div>

				</form>
			</div>
		</div>
	</div>
</div>

@endsection