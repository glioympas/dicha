$('.select2').select2();

window.clearAlerts = function() {
	$('.top-success, .top-error').text(``).addClass('d-none');
	$('.form-error').remove();
}

window.successAlert = function(msg) {
	let error = $('.top-error');
	if(!error.hasClass('d-none'))
		error.addClass('d-none');

	$('.top-success').html(msg).removeClass('d-none').hide().fadeIn(500);
}

window.errorAlert = function(msg) {
	let success = $('.top-success');
	if(!success.hasClass('d-none'))
		success.addClass('d-none');

	$('.top-error').html(msg).removeClass('d-none').hide().fadeIn(500);
}

window.clearAjaxSpinner = function(form){
	form.find(`[type="submit"]`).find('.ajax-spinner').remove();
}


$(document).on('submit', '.ajax-form', function(){
	let btn = $(this).find(`[type="submit"]`);
	btn.append(`<div class="ajax-spinner spinner-border-sm spinner-border ml-1" role="status">
	  <span class="sr-only">Loading...</span>
	</div>`);
});