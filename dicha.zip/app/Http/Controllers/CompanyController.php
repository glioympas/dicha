<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCompany;
use App\Models\Company;
use App\Notifications\CompanyUpdateNotification;
use Illuminate\Http\Request;

class CompanyController extends Controller
{
    

    public function index()
    {
        $companies = Company::with('employees')->latest();
        $allCount = $companies->count();
        $companies = $companies->paginate(15);

        return view('companies.index', compact('companies' , 'allCount'));
    }


    public function create()
    {
        return view('companies.company_form');
    }

    public function store(StoreCompany $request)
    {
        $company = Company::create($request->all());
        session()->flash('success', __("Company has been created successfully."));

        auth()->user()->notify(new CompanyUpdateNotification($company , true));

        return response()->json(['redirect' => route('companies.edit', $company->id)]);
    }

  
    public function show($id)
    {
        //
    }

  
    public function edit(Company $company)
    {
        return view('companies.company_form', compact('company'));
    }

    public function update(StoreCompany $request, Company $company)
    {
        $company->update($request->all());

        auth()->user()->notify(new CompanyUpdateNotification($company));

        return response()->json(['success' => __("Company has been updated successfully.") ]);
    }

 
    public function destroy(Company $company)
    {
        $company->delete();
        return response()->json(['success' => __("Company $company->name has been deleted successfully.")]);
    }
}
